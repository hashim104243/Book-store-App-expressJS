export const PORT = 5555;

export const MONGODB_URL = "mongodb://127.0.0.1:27017/BookStore_DATABASE";
