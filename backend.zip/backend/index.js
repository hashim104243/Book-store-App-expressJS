import express from "express";
import { PORT, MONGODB_URL } from "./config.js";
import cors from "cors";
import mongoose from "mongoose";
import { Book } from "./Model/bookModel.js";
import bookRoutes from "./routers/bookRoutes.js";
const app = express();
app.use(cors());
// app.use(
//   cors({
//     origin: "https://localhost:3000",
//     methods: ["GET", "POST", "DELETE", "PUT"],
//     allowedHeaders: ["Content-Type"],
//   })
// );
app.use(express.json());
app.use("/books", bookRoutes);

mongoose
  .connect(MONGODB_URL)
  .then(() => {
    console.log("connection successfully wth database");
    app.listen(PORT, () => {
      console.log("app listnening port ", PORT);
    });
  })
  .catch((error) => {
    console.log("error agya ha", error);
  });
