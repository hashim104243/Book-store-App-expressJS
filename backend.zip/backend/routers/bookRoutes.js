import express from "express";
import { Book } from "../Model/bookModel.js";
const router = express.Router();

// sav book in db
router.post("/", async (request, response) => {
  try {
    if (
      !request.body.title ||
      !request.body.author ||
      !request.body.publishYear
    ) {
      return response.status(400).send({
        message: "send all required field title, auther and publish year",
      });
    }

    // const newBook = {
    //   title: request.body.title,
    //   auther: request.body.author,
    //   publishYear: request.body.publishYear,
    // };

    const book = await Book.create(request.body);
    console.log("book is ", book);

    response.status(200).send({
      counts: book.length,
      data: book,
    });
  } catch (error) {
    console.log(error.messaeg);
    response.status(500).send({ message: error.messaeg });
  }
});

// get books from db
router.get("/", async (request, response) => {
  try {
    const allBooks = await Book.find({});
    return response.status(200).json({
      count: allBooks.length,
      books: allBooks,
    });
  } catch (error) {
    console.log("get books error", error);
  }
});

// get books with ID
router.get("/:id", async (request, response) => {
  try {
    const { id } = request.params;
    const book = await Book.findById(id);
    return response.status(200).json(book);
  } catch (error) {
    console.log("get books error", error);
  }
});

// update records
router.put("/:id", async (request, response) => {
  try {
    if (
      !request.body.title ||
      !request.body.author ||
      !request.body.publishYear
    ) {
      return response.status(400).send({
        message: "send all required field title, auther and publish year",
      });
    }

    const { id } = request.params;

    const result = await Book.findByIdAndUpdate(id, request.body);

    if (!result) {
      return response.status(404).json({ message: "book not found" });
    }
    return response.status(200).send({ message: "succesfuly updates" });
  } catch (error) {
    console.log(error.message);
    response.status(500).send("message", error.message);
  }
});

// delete records
router.delete("/:id", async (request, response) => {
  try {
    const { id } = request.params;
    const result = await Book.findByIdAndDelete(id);
    if (!result) {
      return response.status(404).json({ message: "book not found" });
    }
    response.status(200).json({ message: "deleted successfully" });
  } catch (error) {
    console.log(error.message);
    response.status(500).send("message", error.message);
  }
});

export default router;
